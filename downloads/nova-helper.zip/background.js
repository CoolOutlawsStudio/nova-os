// Nova Helper: strips X-Frame-Options and CSP (frame-ancestors) from sub-frame
// responses, but ONLY in tabs that are running Nova OS. Normal browsing is untouched.
const isNova = u => !!u && /webos[^/]*\.html/i.test(u.split(/[?#]/)[0]);
const novaTabs = new Set();
const RULE_ID = 1;

// Rule updates are chained so they never overlap; each run reads the latest state.
let chain = Promise.resolve();
function sync() { chain = chain.then(applyRules).catch(e => console.warn('Nova Helper:', e)); return chain; }
async function applyRules() {
  const { enabled = true } = await chrome.storage.local.get('enabled');
  const tabIds = enabled ? [...novaTabs] : [];
  const addRules = tabIds.length ? [{
    id: RULE_ID, priority: 1,
    action: { type: 'modifyHeaders', responseHeaders: [
      { header: 'x-frame-options', operation: 'remove' },
      { header: 'content-security-policy', operation: 'remove' },
      { header: 'content-security-policy-report-only', operation: 'remove' },
      { header: 'cross-origin-opener-policy', operation: 'remove' },
      { header: 'cross-origin-embedder-policy', operation: 'remove' },
      { header: 'cross-origin-resource-policy', operation: 'remove' }
    ]},
    condition: { resourceTypes: ['sub_frame'], tabIds }
  }] : [];
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [RULE_ID], addRules });
  chrome.action.setBadgeText({ text: tabIds.length ? 'ON' : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#6366f1' });
}

function track(tabId, url) {
  const had = novaTabs.has(tabId);
  if (isNova(url)) novaTabs.add(tabId); else novaTabs.delete(tabId);
  if (had !== novaTabs.has(tabId) || novaTabs.has(tabId)) sync();
}

async function rescan() {
  const tabs = await chrome.tabs.query({});
  novaTabs.clear();
  for (const t of tabs) if (isNova(t.url)) novaTabs.add(t.id);
  return sync();
}

chrome.tabs.onUpdated.addListener((id, info, tab) => { if (info.url || info.status === 'loading') track(id, tab.url); });
chrome.tabs.onRemoved.addListener(id => { if (novaTabs.delete(id)) sync(); });
chrome.tabs.onReplaced.addListener(() => rescan());
chrome.runtime.onStartup.addListener(rescan);
chrome.runtime.onInstalled.addListener(rescan);
chrome.storage.onChanged.addListener(c => { if (c.enabled) sync(); });
chrome.runtime.onMessage.addListener((m, s, reply) => {
  if (m === 'status') { chrome.storage.local.get('enabled').then(({ enabled = true }) => reply({ enabled, tabs: novaTabs.size })); return true; }
});
rescan();
