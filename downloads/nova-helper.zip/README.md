# Nova Helper (Chrome / Edge extension)
Lets sites like YouTube and Google open inside Nova OS's Browser window.
It only works in tabs running `webos.html`; normal browsing is untouched.

## Install (one time)
1. Unzip `nova-helper.zip` to a folder you'll keep.
2. Open `chrome://extensions` (Edge: `edge://extensions`) and turn on **Developer mode** (top right).
3. Click **Load unpacked** and pick the unzipped folder.
4. Click **Details** on Nova Helper and turn on **Allow access to file URLs** (needed because webos.html opens from your disk).
5. Reload webos.html. The toolbar icon shows **ON** while a Nova OS tab is open.

## For the OS
The helper sets `document.documentElement.dataset.novaHelper = "1"` and posts
`{type:'nova-helper', installed:true}` on webos pages, so the Browser app can skip its blocked-site card.
