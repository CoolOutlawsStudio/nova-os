// Tells Nova OS the helper is installed so its Browser can skip the "can't be shown here" card.
document.documentElement.dataset.novaHelper = '1';
window.postMessage({ type: 'nova-helper', installed: true, version: '1.0.1' }, '*');
