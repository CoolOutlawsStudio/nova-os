const on=document.getElementById('on'),s=document.getElementById('s');
chrome.runtime.sendMessage('status',r=>{on.checked=r.enabled;s.textContent=r.tabs?`Active in ${r.tabs} Nova OS tab${r.tabs>1?'s':''}.`:'Open webos.html to use it.'});
on.onchange=()=>chrome.storage.local.set({enabled:on.checked});
